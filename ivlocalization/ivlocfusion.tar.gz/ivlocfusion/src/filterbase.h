/**************************************************************
Copyright (C) 2015-2020, idriverplus(Beijing ZhiXingZhe Inc.

NodeName: ivlocfushion_node
FileName: filter_base.h

Description:
1. Serve as base class for EKF;

History:
WangLeijie  17/09/13  1.0.0 built this module.
************************************************************/
#ifndef FILTER_BASE_H
#define FILTER_BASE_H

// c++ lib
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <fstream>
// msg lib
#include "ivlocmsg/ivsensorgps.h"
#include "ivlocmsg/ivsensorimu.h"
#include "ivlocmsg/ivmsglocpos.h"
//#include "ivsensorodom/ivsensorodom.h"
// ros lib
#include "ros/ros.h"
#include "ros/time.h"
#include <sensor_msgs/Imu.h>

//for Eigen
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include "newconst.h"

using namespace std;

class KalmanFilterBase
{
  private:

    long counter;
    int ntype;

    double Step;

    double rm;
    double rn;

    int HH_mode;        //0--GPS_OK  1--ZUPT  2--MC

    Eigen::MatrixXd F;
    Eigen::MatrixXd FF;
    Eigen::MatrixXd G;
    Eigen::MatrixXd Q;
    Eigen::MatrixXd Qk1;

    Eigen::MatrixXd H;
    Eigen::MatrixXd Rk;

    Eigen::MatrixXd Pk;
    Eigen::MatrixXd Pkk1;

    Eigen::MatrixXd Kk;

    Eigen::VectorXd Xk;
    Eigen::VectorXd Xkk1;
    Eigen::VectorXd Zk;

    Eigen::VectorXd fn;
    Eigen::VectorXd InsVelo;
    Eigen::VectorXd InsPos;
    Eigen::VectorXd f_Vn_pole_COM;
    Eigen::VectorXd f_Rn_pole_COM;

    Eigen::MatrixXd Cbt;

  public:
    KalmanFilterBase();
    ~KalmanFilterBase();

    void Kalman(const Eigen::VectorXd& zk);
  //virtual void AdaptiveKalman(const Matrix& zk);
    void SetStep(double step);
    void SetXk(const Eigen::VectorXd& xk);

    void Initial_KFPara(int stage);
    void Set_HH_Mode(int mode);

    void SetNowInsPara(const Eigen::VectorXd& Sinsinfo,const Eigen::MatrixXd& cbt);

    const Eigen::VectorXd& GetXk();
    const Eigen::MatrixXd& GetPk();

  protected:
    virtual void FMatrix();
    virtual void GMatrix(){};
    virtual void HMatrix(){};

private:
    void Discrete();

};

#endif  //FILTER_BASE_H