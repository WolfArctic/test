#ifndef _PSINS_H
#define _PSINS_H

#include <string.h>

//For Eigen
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#define RAMAX 10

#define  MAX_    20
#define  MIN_    0.05

//#define  EPSILLON  0.000001
//#define  EPS   2.220446049e-16F
//#define INF   3.402823466e+30F

class CRAvar
{
  public:
    CRAvar(void);
    CRAvar(int nR0, int maxCount0=2);
    void setsapmletime(double t);
    void set(double r0, double tau, double rmax=0.0, double rmin=0.0, int i=0);
    void set(const Eigen::Vector3d &r0, const Eigen::Vector3d &tau, const Eigen::Vector3d &rmax, const Eigen::Vector3d &rmin);
    void set(const Eigen::VectorXd &r0, const Eigen::VectorXd &tau, const Eigen::VectorXd &rmax, const Eigen::VectorXd &rmin);
    void Update(double r, double ts, int i=0);
    void Update(const Eigen::Vector3d &r, double ts);
    void Update(const Eigen::VectorXd &r, double ts);

    int Rmaxflag[RAMAX];

    double R0[RAMAX], Rmax[RAMAX];

 //   double operator()(int k);     // get element sqrt(R0(k))
private:
    int nR0, maxCount;
    double ts, /*R0[RAMAX], Rmax[RAMAX], */Rmin[RAMAX], tau[RAMAX], r0[RAMAX];
};

#endif