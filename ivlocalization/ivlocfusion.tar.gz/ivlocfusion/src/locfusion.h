/****************************************************************
* Copyright (C) 2015-2020, idriverplus(BeiJing ZhiXingZhe, Inc.)
*
* NodeName: ivlocfusion
* FileName: locfusion.h, locfusion.cpp
*
* Description:
* 1. Receiving data from GPS/IMU/ODOM
* 2. Calculating Extended Kalman Filter.
* 3. Publishing filtered data.
*
* History:
* Wang Leijie   17/09/03    1.0.0    build this module.
****************************************************************/

#ifndef _LOCFUSION_H
#define _LOCFUSION_H
//#pragma once

// c++ lib
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <iostream>
// msg lib
#include "ivlocmsg/ivsensorgps.h"
#include "ivlocmsg/ivsensorimu.h"
#include "ivlocmsg/ivmsglocpos.h"
//#include "ivlocmsg/ivsensorodom.h"
// ros lib
#include "ros/ros.h"
#include "ros/time.h"
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
//for tf
#include <tf2_ros/transform_broadcaster.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2/LinearMath/Quaternion.h>

//For Eigen
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

//customed
#include "newconst.h"
#include "filterbase.h"
#include "ins_calculate.h"

#include "psins.h"

// other lib
#include "../../../avoslib/geotool.h"
#include "../../../avoslib/globalvariables.h"
//#include "../../../avoslib/iabasemaptool.h"

using namespace std;

#define INVALID_VALUE 8888
#define SUBBUF_LEN   10
#define SUBTOPIC_GPS "ivsensorgps"
#define SUBTOPIC_IMU "ivsensorimu"
#define SUBTOPIC_ODOM "ivsensorodom"
#define PUBTOPIC     "ivlocpos"
#define SUBTOPIC_IMURT "ivstdimu"
#define PUB_NAV_TOPIC "ivnav"           //  sensor_msg/Imu
//#define SUBTOPIC_IMURT "ivstdimu"

#define ZUPT_Velocity  1

class locfusion
{
  public:
    //! Constructor.
    locfusion(ros::NodeHandle nh);
    ~locfusion();
    void Run();
    bool initial_flag;

    geotool geoTool;

    int gps_counter;
    int imu_counter;
    int ins_counter;
    int kf_counter;

    ofstream imu_out;         //for debug
    ofstream gps_out;         //for debug
    ofstream nav_out;         //for debug

  private:

    void ChatterCallback_Gps(const ivlocmsg::ivsensorgps::ConstPtr& msg);
    void ChatterCallback_Imu(const ivlocmsg::ivsensorimu::ConstPtr& msg);
    //void ChatterCallback_Odom(const ivsensorodom::ivsensorodom::ConstPtr &msg);

    void ChatterCallback_ImuRT(const sensor_msgs::Imu::ConstPtr& msg);

    void FuseLoc();

    int loopFrep;

    ivlocmsg::ivmsglocpos locMsg;

    ivlocmsg::ivsensorgps currentGps;
    ivlocmsg::ivsensorgps previousGps;
    ivlocmsg::ivsensorgps iabasemapTL;

    ivlocmsg::ivsensorimu currentImu;
    //ivlocmsg::ivsensorodom currentOdom;

    sensor_msgs::Imu currentImuRT;

    sensor_msgs::Imu msg_nav;

    ros::Publisher  pub_ros_nav;
    ros::Publisher  pubLoc;
    ros::Subscriber subGps;
    ros::Subscriber subImu;
    ros::Subscriber subImuRT;
    //ros::Subscriber subOdom;

    float ins_step;
    float kf_step;

    //flags
    int stage;
    int GPSData_OK;
    int Initial_KFPara_flag;
    int i_aligment_flag;

    unsigned char InitAlignMode;

    int ImuDataReady;

    unsigned char GPSDataReady;

    KalmanFilterBase  mykf;
    SinsCal  mysinscal;

    Eigen::VectorXd Zk;
    Eigen::VectorXd SinsInfo;
    Eigen::MatrixXd Cbn;

    Eigen::VectorXd MC_Velo;
    Eigen::VectorXd MC_GPS_Velo;

    double Pos[3];
    double Velo[3];
    double Eulera[3];
    double fn[3];
    double f_vn_pole[3];
    double f_rn_pole[3];

    double rm;
    double rn;

    double pitch_out;
    double roll_out;
    double heading_out;

    bool save_navdata;
    bool gps_is_Horizontal;

    bool ZUPT_init_flag;

    bool ZUPT_flag;
    bool MC_flag;

    int mode;

    FILE *fpnav;

    CRAvar ravar;

//    Eigen::Vector6d imu_in;

};

#endif // _LOCALIZATION_H
