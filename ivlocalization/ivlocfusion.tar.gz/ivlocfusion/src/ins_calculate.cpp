/**************************************************************
Copyright (C) 2015-2020, idriverplus(Beijing ZhiXingZhe Inc.

NodeName: ivlocfushion_node
FileName: ins_calculate.cpp

Description:
1. IMU Data Process;

History:
WangLeijie  17/09/13  1.0.0 built this module.
************************************************************/

#include "ins_calculate.h"

SinsCal::SinsCal() : SinsInfo(17),strapdown(3,3)
{
    t_step = 0.01;

    Rn=Re;
    Rm=Re;
    ins_calculate_counter=0;

    i_InitialAlign = 0;

    f_H = 0.0;

    for(int i=0; i<3; i++)
    {
        f_Fab[i] = 0;
        f_Wibb[i] = 0;

        f_Winn[i] = 0;
        f_Winb_COM[i] = 0;
        f_Wnbb_COM[i] = 0;

        Vp[i]=0;
        Pos[i]=0;
        Eulera[i]=0;

        f_Vn_pole_COM[i] = 0;
        f_Rn_pole_COM[i] = 0;
    }

    for(int i=0; i<3; i++)
    {
       for(int j=0; j<3; j++)
      {
          Cbn[i][j]=0;
          if(i==j)
            Cbn[i][j]=1;
          else
            Cbn[i][j]=0;
      }
    }

    for(int i=0; i<4; i++)
      Quater[i]=0;

    ins_nav_out.open("../out/ins_cal.txt");
}

SinsCal::~SinsCal()
{
    ins_nav_out.close();
}

void SinsCal::ins_calculate(double sourcedata[])
{
    float  f_Ddegree = 0.0, f_Cddeg = 0.0, f_Sddeg = 0.0;
    float  f_Fntemp[3] = {0.0,0.0,0.0}, f_Vntemp[3] = {0.0,0.0,0.0};
    double f_Positemp = 0.0;
    float  f_Sinsg = 0.0;
    int k=0;
    int i=0;

    float f_W_pole[3]={0.0,0.0,0.0};

    if(i_InitialAlign == 1)
    {
        ins_calculate_counter++;

        f_Fab[0] = sourcedata[0];
        f_Fab[1] = sourcedata[1];
        f_Fab[2] = sourcedata[2];

        f_Wibb[0] = sourcedata[3];
        f_Wibb[1] = sourcedata[4];
        f_Wibb[2] = sourcedata[5];

        Rm = Re*(1-2*E+3*E*sin(Pos[1])*sin(Pos[1]));
        Rn = Re*(1+E*sin(Pos[1])*sin(Pos[1]));
        f_H = Pos[2];

        f_Winn[0] = -Vp[1]/(Rm+f_H);
        f_Winn[1] = W_IEE*cos(Pos[1])+Vp[0]/(Rn+f_H);
        f_Winn[2] = W_IEE*sin(Pos[1])+tan(Pos[1])*Vp[0]/(Rn+f_H);

        f_Winb_COM[0] = Cbn[0][0]*f_Winn[0]+Cbn[1][0]*f_Winn[1]+Cbn[2][0]*f_Winn[2];
        f_Winb_COM[1] = Cbn[0][1]*f_Winn[0]+Cbn[1][1]*f_Winn[1]+Cbn[2][1]*f_Winn[2];
        f_Winb_COM[2] = Cbn[0][2]*f_Winn[0]+Cbn[1][2]*f_Winn[1]+Cbn[2][2]*f_Winn[2];

        for(k=0;k<3;k++)
        {
            f_Wnbb_COM[k] = (f_Wibb[k]-f_Winb_COM[k])*t_step;
        }

        f_Ddegree = f_Wnbb_COM[0]*f_Wnbb_COM[0]+f_Wnbb_COM[1]*f_Wnbb_COM[1]+f_Wnbb_COM[2]*f_Wnbb_COM[2];

        f_Cddeg = 1.0-f_Ddegree/8.0+f_Ddegree*f_Ddegree/384.0;
        f_Sddeg = 0.5-f_Ddegree/48.0+f_Ddegree*f_Ddegree/3840.0;

        Quater_temp[0] = f_Cddeg*Quater[0]-f_Sddeg*(f_Wnbb_COM[0]*Quater[1]+f_Wnbb_COM[1]*Quater[2]+f_Wnbb_COM[2]*Quater[3]);
        Quater_temp[1] = f_Cddeg*Quater[1]+f_Sddeg*(f_Wnbb_COM[0]*Quater[0]+f_Wnbb_COM[2]*Quater[2]-f_Wnbb_COM[1]*Quater[3]);
        Quater_temp[2] = f_Cddeg*Quater[2]+f_Sddeg*(f_Wnbb_COM[1]*Quater[0]-f_Wnbb_COM[2]*Quater[1]+f_Wnbb_COM[0]*Quater[3]);
        Quater_temp[3] = f_Cddeg*Quater[3]+f_Sddeg*(f_Wnbb_COM[2]*Quater[0]+f_Wnbb_COM[1]*Quater[1]-f_Wnbb_COM[0]*Quater[2]);

        f_Ddegree = sqrt(Quater_temp[0]*Quater_temp[0]+Quater_temp[1]*Quater_temp[1]+Quater_temp[2]*Quater_temp[2]+Quater_temp[3]*Quater_temp[3]);

        for(k=0;k<4;k++)
        {
            Quater[k] = Quater_temp[k]/f_Ddegree;
        }

        Cbn[0][0] = Quater[0]*Quater[0]+Quater[1]*Quater[1]-Quater[2]*Quater[2]-Quater[3]*Quater[3];
        Cbn[1][1] = Quater[2]*Quater[2]-Quater[3]*Quater[3]+Quater[0]*Quater[0]-Quater[1]*Quater[1];
        Cbn[2][2] = Quater[3]*Quater[3]-Quater[2]*Quater[2]-Quater[1]*Quater[1]+Quater[0]*Quater[0];
        Cbn[0][1] = 2.0  * (Quater[1]*Quater[2]-Quater[0]*Quater[3]);
        Cbn[0][2] = 2.0  * (Quater[1]*Quater[3]+Quater[0]*Quater[2]);
        Cbn[1][0] = 2.0  * (Quater[1]*Quater[2]+Quater[0]*Quater[3]);
        Cbn[1][2] = 2.0  * (Quater[2]*Quater[3]-Quater[0]*Quater[1]);
        Cbn[2][0] = 2.0  * (Quater[1]*Quater[3]-Quater[0]*Quater[2]);
        Cbn[2][1] = 2.0  * (Quater[2]*Quater[3]+Quater[0]*Quater[1]);

        Eulera[0] = atan(Cbn[2][1]/sqrt(Cbn[2][0]*Cbn[2][0]+Cbn[2][2]*Cbn[2][2]));
        Eulera[1] = atan2(-Cbn[2][0],Cbn[2][2]);
        Eulera[2] = atan2(-Cbn[0][1],Cbn[1][1]);

        if(Eulera[2]<0.0)
        {
            Eulera[2] += 2.0 * M_PI;
        }

        f_Fn_COM[0] = Cbn[0][0]*f_Fab[0]+Cbn[0][1]*f_Fab[1]+Cbn[0][2]*f_Fab[2];
        f_Fn_COM[1] = Cbn[1][0]*f_Fab[0]+Cbn[1][1]*f_Fab[1]+Cbn[1][2]*f_Fab[2];
        f_Fn_COM[2] = Cbn[2][0]*f_Fab[0]+Cbn[2][1]*f_Fab[1]+Cbn[2][2]*f_Fab[2];

        Pos[2] = Pos[2]+t_step*Vp[2];
        Pos[1] = Pos[1]+t_step*Vp[1]/(Rm+f_H);
        f_Positemp = (double)(Vp[0]/((Rn+f_H)*cos(Pos[1])));
        Pos[0] = Pos[0]+t_step*f_Positemp;
        f_Positemp = f_Positemp+2.0*W_IEE;

        f_Sinsg = 9.7803+0.051799*sin(Pos[1])*sin(Pos[1])-0.94114*0.000001*Pos[2];

        f_Fntemp[0] = f_Fn_COM[0]+f_Positemp*sin(Pos[1])*Vp[1]-f_Positemp*cos(Pos[1])*Vp[2];
        f_Fntemp[1] = f_Fn_COM[1]-f_Positemp*sin(Pos[1])*Vp[0]-Vp[1]*Vp[2]/(Rm+f_H);
        f_Fntemp[2] = f_Fn_COM[2]+f_Positemp*cos(Pos[1])*Vp[0]-f_Sinsg+Vp[1]*Vp[1]/(Rm+f_H);

        f_Vntemp[0] = Vp[0]+t_step*f_Fntemp[0];
        f_Vntemp[1] = Vp[1]+t_step*f_Fntemp[1];
        f_Vntemp[2] = Vp[2]+t_step*f_Fntemp[2];

        Vp[0] = f_Vntemp[0];
        Vp[1] = f_Vntemp[1];
        Vp[2] = f_Vntemp[2];

        f_W_pole[0] =  f_Wibb[1]*Rz-f_Wibb[2]*Ry;
        f_W_pole[1] = -f_Wibb[0]*Rz+f_Wibb[2]*Rx;
        f_W_pole[2] =  f_Wibb[0]*Ry-f_Wibb[1]*Rx;

        f_Vn_pole_COM[0] = Cbn[0][0]*f_W_pole[0]+Cbn[0][1]*f_W_pole[1]+Cbn[0][2]*f_W_pole[2];
        f_Vn_pole_COM[1] = Cbn[1][0]*f_W_pole[0]+Cbn[1][1]*f_W_pole[1]+Cbn[1][2]*f_W_pole[2];
        f_Vn_pole_COM[2] = Cbn[2][0]*f_W_pole[0]+Cbn[2][1]*f_W_pole[1]+Cbn[2][2]*f_W_pole[2];

        f_Rn_pole_COM[0] = Cbn[0][0]*Rx+Cbn[0][1]*Ry+Cbn[0][2]*Rz;
        f_Rn_pole_COM[1] = Cbn[1][0]*Rx+Cbn[1][1]*Ry+Cbn[1][2]*Rz;
        f_Rn_pole_COM[2] = Cbn[2][0]*Rx+Cbn[2][1]*Ry+Cbn[2][2]*Rz;

/*
        std::cout << setprecision(10)
              << "lon:" << Pos[0]*R2D<<"     "
              << "lat: "<< Pos[1]*R2D<<"     "
              << "height: " << Pos[2]<<"     "
              << "Ve: " << Vp[0]<<"     "
              << "Vn: " << Vp[1]<<"     "
              << "Vu: " << Vp[2]<<"     "
              << "pitch: " << Eulera[0]*R2D<<"     "
              << "roll: " << Eulera[1]*R2D<<"     "
              << "yaw: " << Eulera[2]*R2D<<"     "
              << "counter: "<<ins_counter
              <<std::endl;

        ins_nav_out << setprecision(10)<< Pos[1] * R2D << "        "
                    <<Pos[0] * R2D<< "        "<< Pos[2]<<"      "
                    << Vp[0] <<"      "<<Vp[1]<<"      "
                    << Vp[2]<<"      "<< Eulera[0]*R2D
                    <<"      "<<Eulera[1]*R2D<<"       "
                    <<Eulera[2]*R2D << "      "
                    << ins_calculate_counter
                    <<std::endl;
*/
    }

}

int SinsCal::InitialCaculate(ivlocmsg::ivsensorgps& GPSData,unsigned char &GPSDataReady,ivlocmsg::ivsensorimu &currentImu,unsigned char &InitAlignMode)
{
    int i_initalaigment_flag = 0;

    static double imu_data[6] = {0.0};
    static double sum_imudata[6] = {0.0};
    static double average_imudata[6] = {0.0};
    static int sum1 = 0,sum2 = 0;

    static int posvelo_ok = 0;

    int i = 0;

    if(i_initalaigment_flag==0 && InitAlignMode == 'D')
    {
        if (GPSData.satenum >=10 && GPSData.status == 4 && GPSDataReady == 1)
        {
            GPSDataReady = 0;

            Pos[0] = GPSData.lon;
            Pos[1] = GPSData.lat;
            Pos[2] = GPSData.height;

            Vp[0] = GPSData.ve;
            Vp[1] = GPSData.vn;
            Vp[2] = GPSData.vu;

            //Eulera
            Eulera[0] = 0;
            Eulera[1] = 0;
            Eulera[2] = -(GPSData.heading-GPS_IMU_FIX_ERROR);

            i_initalaigment_flag = 1;

            Initial_Cbn();
            i_InitialAlign = 1;
        }

        return i_initalaigment_flag;
    }

    if(i_initalaigment_flag==0 && InitAlignMode == 'Z')
    {
        if (GPSData.satenum >=8 && GPSData.status == 4 && GPSDataReady == 1)
        {
            GPSDataReady = 0;

            Pos[0] = GPSData.lon;
            Pos[1] = GPSData.lat;
            Pos[2] = GPSData.height;

            Vp[0] = GPSData.ve;
            Vp[1] = GPSData.vn;
            Vp[2] = GPSData.vu;

            Eulera[2] = -(GPSData.heading-GPS_IMU_FIX_ERROR);

            posvelo_ok = 1;
        }

        if(posvelo_ok == 1)
        {
            imu_data[1] = currentImu.accelerationX;
            imu_data[0] = currentImu.accelerationY;
            imu_data[2] = -currentImu.accelerationZ;

            imu_data[4] = currentImu.angularRateX;        //rad
            imu_data[3] = currentImu.angularRateX;
            imu_data[5] = -currentImu.angularRateX;

            sum1++;
            if(sum1*t_step<THROWING_TIME)
            {
                return i_initalaigment_flag;
            }

            sum2++;
            for(i=0;i<6;i++)
            {
                sum_imudata[i] += imu_data[i];
            }

            if (sum2*t_step<ALIGNMENT_TIME)
            {
                return i_initalaigment_flag;
            }

            for(i=0;i<6;i++)
            {
                average_imudata[i] = sum_imudata[i]/sum2;
            }

            //get pitch and roll
            Eulera[0]=atan2(average_imudata[1],sqrt(average_imudata[0]*average_imudata[0]+average_imudata[2]*average_imudata[2]));
            Eulera[1]=atan2(-average_imudata[0],average_imudata[2]);

            for(i=0;i<6;i++)
            {
                average_imudata[i] = 0.0;
            }

            Initial_Cbn();

            sum1 = 0;
            sum2 = 0;

            i_initalaigment_flag = 1;

            std::cout<<"Aligment Result:"<<std::endl;
            std::cout<<"Longtitude:"<<Pos[0]*R2D<<"    "
                     <<"Latitude:"<<Pos[1]*R2D<<"     "
                     <<"Heiht:"<<Pos[2]<<"     "
                     <<"Ve:"<<Vp[0]<<"     "
                     <<"Vn:"<<Vp[1]<<"     "
                     <<"Vu:"<<Vp[2]<<"     "
                     <<"Pitch:"<<Eulera[0]*R2D<<"     "
                     <<"Roll:"<<Eulera[1]*R2D<<"     "
                     <<"Yaw:"<<Eulera[2]*R2D
                     <<std::endl;

            i_InitialAlign = 1;

            return i_initalaigment_flag;
        }

    }

    return i_initalaigment_flag;

}

void SinsCal::Initial_Cbn()
{
    double  sa[3] = {0.0, 0.0, 0.0}, ca[3] = {0.0, 0.0, 0.0};
    int k = 0;

    for(k=0;k<3;k++)
    {
        sa[k]=sin(Eulera[k]/2.0);
        ca[k]=cos(Eulera[k]/2.0);
    }

    Quater[0]=ca[2]*ca[0]*ca[1]-sa[2]*sa[0]*sa[1];
    Quater[1]=ca[2]*sa[0]*ca[1]-sa[2]*ca[0]*sa[1];
    Quater[2]=ca[2]*ca[0]*sa[1]+sa[2]*sa[0]*ca[1];
    Quater[3]=ca[2]*sa[0]*sa[1]+sa[2]*ca[0]*ca[1];

    for(k=0;k<3;k++)
    {
        sa[k]=sin(Eulera[k]);
        ca[k]=cos(Eulera[k]);
    }

    Cbn[0][0]=ca[1]*ca[2]-sa[1]*sa[0]*sa[2];
    Cbn[1][0]=ca[1]*sa[2]+sa[1]*sa[0]*ca[2];
    Cbn[2][0]=-sa[1]*ca[0];
    Cbn[0][1]=-ca[0]*sa[2];
    Cbn[1][1]=ca[0]*ca[2];
    Cbn[2][1]=sa[0];
    Cbn[0][2]=sa[1]*ca[2]+ca[1]*sa[0]*sa[2];
    Cbn[1][2]=sa[1]*sa[2]-ca[1]*sa[0]*ca[2];
    Cbn[2][2]=ca[1]*ca[0];

    return;
}

const Eigen::VectorXd& SinsCal::GetNavigationInfo()
{
    for(int i=0; i<3; i++)
    {
      SinsInfo(i+3) = Vp[i];
      SinsInfo(i+6) = f_Fn_COM[i];
      SinsInfo(i+9) = f_Vn_pole_COM[i];
      SinsInfo(i+12) = f_Rn_pole_COM[i];
    }

    SinsInfo(0) = Pos[1];       //lat
    SinsInfo(1) = Pos[0];       //lon
    SinsInfo(2) = Pos[2];       //height

    SinsInfo(15) = Rm;
    SinsInfo(16) = Rn;

    return SinsInfo;
}

const Eigen::MatrixXd& SinsCal::GetCbn()
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            strapdown(i,j) = Cbn[i][j];
        }
    }

    return strapdown;
}

void SinsCal::SetTimeStep(double step)
{
    t_step=step;
}

void SinsCal::Feedback(Eigen::VectorXd &Xk)
{
    double gps_v=0.0;
    int i = 0;

    Eigen::MatrixXd matrix(3,3);
    Eigen::MatrixXd cbp(3,3);
    Eigen::MatrixXd dd(3,3);

    double *x =new double[9];

    for(i=0; i<9; i++)
    {
        x[i]=Xk(i);
    }

/*
    std::cout << "X(0): " << Xk(0)<<"     "
              << "X(1): " << Xk(1)<<"     "
              << "X(2): " << Xk(2)<<"     "
              << "X(3): " << Xk(3)<<"     "
              << "X(4): " << Xk(4)<<"     "
              << "X(5): " << Xk(5)<<"     "
              << "X(6): " << Xk(6)<<"     "
              << "X(7): " << Xk(7)<<"     "
              << "X(8): " << Xk(8)<<"     "
              <<std::endl;

    std::cout <<std::endl;
    std::cout <<std::endl;

*/
    for (i=0;i<3;i++)
    {
        Vp[i] = Vp[i] - x[3+i];
    //    Pos[i] = Pos[i] - x[6+i];
    }

    Pos[0] = Pos[0] - x[7];
    Pos[1] = Pos[1] - x[6];
    Pos[2] = Pos[2] - x[8];

    std::cout << setprecision(10)
              << "lat:" << Pos[0]*R2D<<"     "
              << "lon: "<< Pos[1]*R2D<<"     "
              << "height: " << Pos[2]<<"     "
              << "Ve: " << Vp[0]<<"     "
              << "Vn: " << Vp[1]<<"     "
              << "Vu: " << Vp[2]<<"     "
              << "pitch: " << Eulera[0]*R2D<<"     "
              << "roll: " << Eulera[1]*R2D<<"     "
              << "yaw: " << Eulera[2]*R2D<<"     "
              <<std::endl;

    std::cout<<endl;
    std::cout<<endl;

    Initial_Cbn();

    matrix(0,0) = 1.0;
    matrix(0,1) = 0;
    matrix(0,2) = x[1];
    matrix(1,0) = x[0]*x[1];
    matrix(1,1) = 1.0;
    matrix(1,2) = -x[0];
    matrix(2,0) = -x[1];
    matrix(2,1) = x[0];
    matrix(2,2) = 1.0;

/*
    matrix(0,0)=1.0;
    matrix(0,1)=-x[2];
    matrix(0,2)=x[1];
    matrix(1,0)=x[2];
    matrix(1,1)=1.0;
    matrix(1,2)=-x[0];
    matrix(2,0)=-x[1];
    matrix(2,1)=x[0];
    matrix(2,2)=1.0;
*/

    for(i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            cbp(i,j)=Cbn[i][j];
        }
    }

    dd = matrix * cbp;

    cbp = dd;

    Eulera[0] = atan(cbp(2,1)/(sqrt((cbp(2,0)*cbp(2,0)+cbp(2,2)*cbp(2,2)))));
    Eulera[1] = atan2(-cbp(2,0),cbp(2,2));
    Eulera[2] = atan2(-cbp(0,1),cbp(1,1));

    double  sa[3] = {0.0, 0.0, 0.0}, ca[3] = {0.0, 0.0, 0.0};

    for(i=0;i<3;i++)
    {
        sa[i]=sin(Eulera[i]/2.0);
        ca[i]=cos(Eulera[i]/2.0);
    }

    Quater[0]=ca[2]*ca[0]*ca[1]-sa[2]*sa[0]*sa[1];
    Quater[1]=ca[2]*sa[0]*ca[1]-sa[2]*ca[0]*sa[1];
    Quater[2]=ca[2]*ca[0]*sa[1]+sa[2]*sa[0]*ca[1];
    Quater[3]=ca[2]*sa[0]*sa[1]+sa[2]*ca[0]*ca[1];

    double Quater_sum = 0.0;
    Quater_sum = sqrt(Quater[0]*Quater[0]+Quater[1]*Quater[1]+Quater[2]*Quater[2]+Quater[3]*Quater[3]);

    for(i=0;i<4;i++)
    {
        Quater[i] = Quater[i]/Quater_sum;
    }

    for(i=0; i<15; i++)
    {
      Xk(i)=0;
    }

    delete [] x;
}

void SinsCal::Feedback1(Eigen::VectorXd &Xk,ivlocmsg::ivsensorgps& GPSData)
{
    double gps_v=0.0;
    int i = 0;

    Eigen::MatrixXd matrix(3,3);
    Eigen::MatrixXd cbp(3,3);
    Eigen::MatrixXd dd(3,3);

    double *x =new double[9];

    for(i=0; i<9; i++)
    {
        x[i]=Xk(i);
    }

    Vp[0] = Vp[0] - x[3];
    Vp[1] = Vp[1] - x[4];
    Vp[2] = Vp[2] - x[5];

    Pos[0] = Pos[0] - x[7];
    Pos[1] = Pos[1] - x[6];
    Pos[2] = Pos[2] - x[8];

    if (GPSData.satenum>=10 && GPSData.status == 4)
    {
        Eulera[2] = -GPSData.heading;
    }

    Initial_Cbn();

//  [1    Eu  -En]
//  [-Eu  1    Ee]
//  [En   -Ee   1]

/*  //mayunfeng

    //Cnb = Cn'b * Cnn'
    //Cnn'
    matrix(0,0) = 1.0;
    matrix(0,1) = x[2];
    matrix(0,2) = -x[1];
    matrix(1,0) = -x[2];
    matrix(1,1) = 1.0;
    matrix(1,2) = x[0];
    matrix(2,0) = x[1];
    matrix(2,1) = x[0];
    matrix(2,2) = 1.0;

    for(i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            cbp(i,j)=Cbn[i][j];
        }
    }
    //Cn'b
    dd = cbp.transpose() * matrix;
    cbp = dd.transpose();
*/

/*
    matrix(0,0) = 1.0;
    matrix(0,1) = -x[2];
    matrix(0,2) = x[1];
    matrix(1,0) = x[2];
    matrix(1,1) = 1.0;
    matrix(1,2) = -x[0];
    matrix(2,0) = -x[1];
    matrix(2,1) = x[0];
    matrix(2,2) = 1.0;
*/

    matrix(0,0) = 1.0;
    matrix(0,1) = 0;
    matrix(0,2) = x[1];
    matrix(1,0) = x[0]*x[1];
    matrix(1,1) = 1.0;
    matrix(1,2) = -x[0];
    matrix(2,0) = -x[1];
    matrix(2,1) = x[0];
    matrix(2,2) = 1.0;

    for(i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            cbp(i,j)=Cbn[i][j];
        }
    }

    dd = matrix * cbp;
    cbp = dd;

    Eulera[0] = atan(cbp(2,1)/(sqrt((cbp(2,0)*cbp(2,0)+cbp(2,2)*cbp(2,2)))));
    Eulera[1] = atan2(-cbp(2,0),cbp(2,2));
//    Eulera[2] = atan2(-cbp(0,1),cbp(1,1));

/*
    std::cout << setprecision(10)
              << "Ve_error:" << (Vp[0] - GPSData.ve)<<"     "
              << "Vn_error: "<< (Vp[1] - GPSData.vn)<<"     "
              << "Vu_error: "<< (Vp[2] - GPSData.vu)<<"     "
              <<"heading_error:"<<(-GPSData.heading-Eulera[2])*R2D
              <<std::endl;

    std::cout<<endl;
    std::cout<<endl;
*/
    double  sa[3] = {0.0, 0.0, 0.0}, ca[3] = {0.0, 0.0, 0.0};

    for(i=0;i<3;i++)
    {
        sa[i]=sin(Eulera[i]/2.0);
        ca[i]=cos(Eulera[i]/2.0);
    }

    Quater[0]=ca[2]*ca[0]*ca[1]-sa[2]*sa[0]*sa[1];
    Quater[1]=ca[2]*sa[0]*ca[1]-sa[2]*ca[0]*sa[1];
    Quater[2]=ca[2]*ca[0]*sa[1]+sa[2]*sa[0]*ca[1];
    Quater[3]=ca[2]*sa[0]*sa[1]+sa[2]*ca[0]*ca[1];

    double Quater_sum = 0.0;
    Quater_sum = sqrt(Quater[0]*Quater[0]+Quater[1]*Quater[1]+Quater[2]*Quater[2]+Quater[3]*Quater[3]);

    for(i=0;i<4;i++)
    {
        Quater[i] = Quater[i]/Quater_sum;
    }

    for(i=0; i<15; i++)
    {
      Xk(i)=0;
    }

    delete [] x;
}
