/******************************************************************************
 * Copyright (C) 2016, BeiJing ZhiXingZhe, Inc.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * Author Information:
 * WangXiao
 * wangxiao@idriverplum.com, zidan001@163.com
 *
 * NodeName: ivlocalization(ivlocfusion)
 * FileName: ivlocalization.cpp
 *
 * Description:
 * 1. Receiving data from GPS/IMU/ACT.
 * 2. Calculating Extended Kalman Filter.
 * 3. Publishing filtered data.
 *
 * History:
 * Xiao Wang    16/01/01    1.0.0    build this module.
 * Xiaofei Li   17/05/12    1.0.1    build this module.
 * Ziwei Zhao   17/07/10    1.0.2    change name to ivlocfusion
 * You Huang    17/09/12    2.0.0    Rewrite the EKF
*****************************************************************************/

#include "locfusion.h"

int main(int argc, char *argv[])
{
  ros::init(argc, argv, "ivlocfusion");
  ros::NodeHandle nh;
  locfusion node(nh);
  node.Run();
  return 0;
}

