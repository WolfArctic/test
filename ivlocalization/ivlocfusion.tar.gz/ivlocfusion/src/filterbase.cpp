 /* Author Information:
 * WangLeijie
 * wangleijie@idriverplus.com
 *
 * NodeName: ivlocfusion(ivlocfusion)
 * FileName: filterbase.cpp
 *
 * Description:
 * 1. GPS/IMU Kalman Filter Base
 *
 * History:
 * Wang Leijie     17/09/13    1.0.0    build this module.

 */

#include "filterbase.h"

KalmanFilterBase::KalmanFilterBase() :
    F(NN,NN),
    FF(NN,NN),
    G(NN,MM),
    Q(MM,MM),
    Qk1(MM,MM),
    H(MM,NN),
    Rk(MM,MM),
    Pk(NN,NN),
    Pkk1(NN,NN),
    Kk(NN,MM),
    Xk(NN),
    Xkk1(NN),
    Zk(MM),
    fn(ROW),
    InsVelo(ROW),
    InsPos(ROW),
    f_Vn_pole_COM(ROW),
    f_Rn_pole_COM(ROW),
    Cbt(ROW,ROW)
{
    counter=0;

    rn = rm = Re;

    HH_mode = 0;

    F.setZero();
    FF.setZero();
    G.setZero();
    Q.setZero();
    Qk1.setZero();

    H.setZero();
    Rk.setZero();

    Pk.setZero();
    Pkk1.setZero();

    Kk.setZero();

    Xk.setZero();
    Xkk1.setZero();

    Zk.setZero();
}

KalmanFilterBase::~KalmanFilterBase()
{

}

void KalmanFilterBase::Kalman(const Eigen::VectorXd& zk)
{
  Zk = zk;
  Discrete();

  Eigen::MatrixXd I(15,15);
  I.setZero();

  for (int i = 0; i < 15; i++)
  {
    for (int j = 0; j < 15; j++)
    {
      if (i == j)
      {
          I(i,j) = 1;
      }
    }
  }

  Pkk1 = FF * Pk * FF.transpose() + Qk1;
  Kk = Pkk1 * H.transpose() * ( (H * Pkk1 * H.transpose() + Rk ).inverse() );
  Xkk1 = FF * Xk;
  Xk =  Xkk1 + Kk * ( Zk - H * Xkk1);
//Pk = ( I - Kk * H) * Pkk1;
  Pk = (I - Kk * H) * Pkk1 * ( I - Kk * H).transpose() + Kk * Rk * Kk.transpose();

  counter++;
}

/*
void KalmanFilterBase::InitialKalman(const Eigen::MatrixXd& Q0, const Eigen::MatrixXd& R0, const Eigen::MatrixXd& P0, const Eigen::VectorXd& X0)
{
    Q = Q0;
    Q /= Step;     //ÏµÍ³ÔëÉùÕóÀëÉ¢»¯

    Rk = R0;
    Rk /= Step;    //Á¿²âÔëÉùÀëÉ¢»¯

    Pk = P0;
    Xk = X0;
}
*/

void KalmanFilterBase::Discrete()
{
    FMatrix();
    GMatrix();
    HMatrix();

    Eigen::MatrixXd I(NN,NN);//µ¥Î»Õó

    I.setZero();

    for (int i = 1; i <= NN; ++i)
    {
      for (int j = 1; j < NN; ++j)
      {
        if (i == j)
        {
            I(i,j) = 1;
        }
      }
    }

    double step2=Step*Step;

    FF= I + F * Step + 0.5 * F * F * step2;

    Eigen::MatrixXd T(15,6);
    T.setZero();

    T = ( I + ( 0.5* F * Step ) + ( F * F * step2 /6.0)) * G * Step;
    Qk1 = T * Q * T.transpose();
}

void KalmanFilterBase::Initial_KFPara(int stage)
{
    int k1,k2;

    for(k1 = 0; k1 < NN; k1++)
    {
      for(k2 = 0; k2 < NN; k2++)
      {
        Pk(k1,k2) = 0.0;
        Pkk1(k1,k2) = 0.0;
      }
    }

    for(k1 = 0; k1 < NN; k1++)
      for(k2 = 0; k2 < MM; k2++)
        Kk(k1,k2) = 0.0;

    for(k1 = 0; k1 < NOISE; k1++)
      for(k2 = 0; k2 < NOISE; k2++)
        Q(k1,k2) = 0.0;

    for(k1 = 0; k1 < MM; k1++)
      for(k2 = 0; k2 < MM; k2++)
        Rk(k1,k2) = 0.0;

    //angle
    Xk(0) = 2.0*D2R;
    Xk(1) = 2.0*D2R;
    Xk(2) = 1.0*D2R;

    //velo
    Xk(3) = 0.1;
    Xk(4) = 0.1;
    Xk(5) = 0.2;

    //pos
    Xk(6) = (0.00001)*D2R;
    Xk(7) = (0.00001)*D2R;
    Xk(8) = 2.0;

    //acc
    Xk(9) = 0.001*9.8;
    Xk(10) = 0.001*9.8;
    Xk(11) = 0.001*9.8;

    //gyro drift
    Xk(12) = 3*D2R;
    Xk(13) = 3*D2R;
    Xk(14) = 3*D2R;

    for(k1 = 0; k1 < NN; k1++)
      Pk(k1,k1) = Xk(k1) * Xk(k1);
    for(k1 = 0;k1 < NN; k1++)
      Pkk1(k1,k1) = Pk(k1,k1);
/*
    Q(1,1)=5.29e-6;     Q(2,2)=5.29e-6;   Q(3,3)=5.29e-6;
    Q(4,4)=2.5e-1;      Q(5,5)=2.5e-1;    Q(6,6)=2.5e-1;
*/
    for (int i = 0; i < 3; i++)
    {
        Q(i,i) = GYRO_WHITE_NOISE * GYRO_WHITE_NOISE;
        Q(i+3,i+3) = ACCE_DRIFT*ACCE_DRIFT;
    }

    if (stage == 1)     //RTK  fixed
    {
        //pos veloity
        Rk(0,0) = 0.05*0.05;      Rk(1,1) = 0.05*0.05;    Rk(2,2) = 0.1*0.1;
        Rk(3,3) = 0.03*0.03;      Rk(4,4) = 0.03*0.03;    Rk(5,5) = 0.05*0.05;
    }
    else if(stage == 2)   //RTK float
    {
        Rk(0,0) = 0.2*0.2;       Rk(1,1) = 0.2*0.2;     Rk(2,2) = 0.3*0.3;
        Rk(3,3) = 0.05*0.05;     Rk(4,4) = 0.05*0.05;   Rk(5,5) = 0.08*0.08;
    }
    else if(stage == 3)     //RTD
    {
        Rk(0,0) = 0.5*0.5;       Rk(1,1) = 0.5*0.5;    Rk(2,2) = 0.6*0.6;
        Rk(3,3) = 0.08*0.08;     Rk(4,4) = 0.08*0.08;    Rk(5,5) = 0.1*0.1;
    }
    else if(stage == 4)   // single GPS
    {
        Rk(0,0) = 1.5*1.5;       Rk(1,1) = 1.5*1.5;     Rk(2,2) = 2.0*2.0;    //pos
        Rk(3,3) = 0.08*0.08;     Rk(4,4) = 0.08*0.08;   Rk(5,5) = 0.1*0.1;    //velocity
    }
    else if(stage == 5)   //Zero velocity update
    {
        Rk(0,0) = 0.2*0.2;      Rk(1,1) = 0.2*0.2;    Rk(2,2) = 0.3*0.3;    //pos
        Rk(3,3) = 0.05*0.05;      Rk(4,4) = 0.05*0.05;    Rk(5,5) = 0.05*0.05;    //velocity
    }
    else if(stage == 6)   //Moving constraint
    {
        Rk(0,0) = 0.5*0.5;      Rk(1,1) = 0.5*0.5;    Rk(2,2) = 0.6*0.6;    //pos
        Rk(3,3) = 0.1*0.1;      Rk(4,4) = 0.1*0.1;    Rk(5,5) = 0.2*0.2;    //velocity
    }

    for (int i = 0; i < NN; i++)
    {
       Xk(i) = 0;
    }

    for(k1=0;k1<NOISE;k1++)
          Q(k1,k1)=Q(k1,k1)/Step;

    for(k1=0;k1<MM;k1++)
          Rk(k1,k1)=Rk(k1,k1)/Step;

    return;
}

void KalmanFilterBase::SetStep(double step)
{
   Step=step;
}

void KalmanFilterBase::SetXk(const Eigen::VectorXd& xk)
{
   Xk = xk;
}

const Eigen::VectorXd& KalmanFilterBase::GetXk()
{
  return Xk;
}

const Eigen::MatrixXd& KalmanFilterBase::GetPk()
{
  return Pk;
}

void KalmanFilterBase::FMatrix()
{
  double x1,x2,x3;
  double height;
  double Ve,Vn,Vu;
  double fai1,fai2;
  double temp1,temp2;

  x1=sin(InsPos(0));//sinL
  x2=cos(InsPos(0));//cosL
  x3=tan(InsPos(0));//tanL

  height=InsPos(2);//h

  fai1=sin(InsPos(1));//sinJ
  fai2=cos(InsPos(1));//cosJ

  Ve=InsVelo(0);
  Vn=InsVelo(1);
  Vu=InsVelo(2);

  rm=Re*(1-2*Rf+3*Rf*x1*x1);
  rn=Re*(1+Rf*x1*x1);

  temp1=1.0/(rn+height);
  temp2=1.0/(rm+height);

  //F9X9
  F(0,1)=W_IEE*x1+Ve*x3*temp1;
  F(0,2)=-(W_IEE*x2+Ve*temp1);
  F(0,4)=-temp2;

  F(1,0)=-F(0,1);
  F(1,2)=-Vn*temp2;
  F(1,3)=temp1;
  F(1,6)=-W_IEE*x1;

  F(2,0)=-F(0,2);
  F(2,1)=-F(1,2);
  F(2,3)=x3*temp1;
  F(2,6)=W_IEE*x2+Ve*(1.0/x2)*(1.0/x2)*temp1;

  F(3,1)=-fn(2);
  F(3,2)=fn(1);
  F(3,3)=(Vn*x3-Vu)*temp2;
  F(3,4)=2.0*W_IEE*x1+Ve*x3*temp1;
  F(3,5)=-(2.0*W_IEE*x2+Ve*temp1);
  F(3,6)=2.0*W_IEE*Vn*x2+Ve*Vn*temp1*(1.0/x2)*(1.0/x2)+2.0*W_IEE*Vu*x1;

  F(4,0)=fn(2);
  F(4,2)=-fn(0);
  F(4,3)=-2.0*(W_IEE*x1+Ve*x3*temp1);
  F(4,4)=-Vu*temp2;
  F(4,5)=-Vn*temp2;
  F(4,6)=-(2.0*W_IEE*x2+Ve*(1.0/x2)*(1.0/x2)*temp1)*Ve;

  F(5,0)=-fn(1);
  F(5,1)=fn(0);
  F(5,3)=2.0*(W_IEE*x2+Ve*temp1);
  F(5,4)=2.0*Vn*temp2;
  F(5,6)=-2.0*Ve*W_IEE*x1;

  F(6,4)=temp2;

  F(7,3)=temp1/x2;
  F(7,6)=x3/x2*Ve*temp1;

  F(8,5)=1.0;

  //Fs(9*6)
  //cbt   O33
  //O33   cbt
  //O33   O33

  for (int i = 0; i < 3;++i)
  {
     F(0,9+i) = Cbt(0,i);
     F(1,9+i) = Cbt(1,i);
     F(2,9+i) = Cbt(2,i);

     F(3,12+i) = Cbt(0,i);
     F(4,12+i) = Cbt(1,i);
     F(5,12+i) = Cbt(2,i);
  }

  //  | FN99  Fs96|
  //F=|           |
  //  |       FM66|

  //cbt   O33
  //O33   cbt
  //O93   O93


//G 15*6 Matrix
  for (int i = 0; i < 3; i++)
  {
     G(0,i) = Cbt(0,i);
     G(1,i) = Cbt(1,i);
     G(2,i) = Cbt(2,i);

     G(3,3+i) = Cbt(0,i);
     G(4,3+i) = Cbt(1,i);
     G(5,3+i) = Cbt(2,i);
  }

  //Hv=[O33 diag[1 1 1] O3*12]
  //Hp=[O36  diag[Rm Rn*cosL 1] O39]


/*
  //Hv
  H(0,3) = 1;
  H(1,4) = 1;
  H(2,5) = 1;

  //Hp
  H(3,6) = -(rn+height)*x1*fai2;
  H(3,7) = -(rn+height)*x2*fai1;
  H(3,8) = x2*fai2;

  H(4,6) = -(rn+height)*x1*fai1;
  H(4,7) = (rn+height)*x2*fai2;
  H(4,8) = x2*fai1;

  H(5,6) = (rn*(1.0-Rf)*(1.0-Rf)+height)*x2;
  H(5,8) = x1;

  */

  if (HH_mode == 0)   //GPS_OK
  {
    H(0,6) = 1.0*(rm+height);
    H(1,7) = 1.0*(rn+height)*x2;
    H(2,8) = 1.0;
    H(3,3) = 1.0;
    H(4,4) = 1.0;
    H(5,5) = 1.0;
  }
  else if(HH_mode == 1)   //ZUPT
  {
    H(0,6) = 0;
    H(1,7) = 0;
    H(2,8) = 0;
    H(3,3) = 1.0;
    H(4,4) = 1.0;
    H(5,5) = 1.0;
  }
  else if(HH_mode == 2)   ///MC
  {
    H(0,6) = 0;
    H(1,7) = 0;
    H(2,8) = 0;
    H(3,3) = 1.0;
    H(4,4) = 1.0;
    H(5,5) = 1.0;
  }

}

void KalmanFilterBase::SetNowInsPara(const Eigen::VectorXd& Sinsinfo,const Eigen::MatrixXd& cbt)
{
    int i,j;

    for (int i = 0; i < 3; i++)
    {
        InsPos(i) = Sinsinfo(i);
        InsVelo(i) = Sinsinfo(i+3);
        fn(i) = Sinsinfo(i+6);
        f_Vn_pole_COM(i) = Sinsinfo(i+9);
        f_Rn_pole_COM(i) = Sinsinfo(i+12);
    }

    rm = Sinsinfo(15);
    rn = Sinsinfo(16);

    Cbt = cbt;
}

void KalmanFilterBase::Set_HH_Mode(int mode)
{
  HH_mode = mode;
}