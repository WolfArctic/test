/**************************************************************
Copyright (C) 2015-2020, idriverplus(Beijing ZhiXingZhe Inc.

NodeName: ivlocfushion_node
FileName: ins_calculate.h

Description:
1. IMU Data Process;

History:
WangLeijie  17/09/13  1.0.0 built this module.
************************************************************/
#ifndef INS_CALCULATE_H
#define INS_CALCULATE_H

// c++ lib
#include <stdio.h>
#include <iostream>
#include <fstream>

// msg lib
#include "ivlocmsg/ivsensorimu.h"
#include "ivlocmsg/ivsensorgps.h"

// ros lib
#include "ros/ros.h"
#include "ros/time.h"
#include <sensor_msgs/Imu.h>

//For Eigen
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include "newconst.h"

using namespace std;

class SinsCal
{

public:

    SinsCal();
    ~SinsCal();

   int InitialCaculate(ivlocmsg::ivsensorgps& GPSData,unsigned char & GPSDataReady,ivlocmsg::ivsensorimu &currentImuRT,unsigned char &InitAlignMode);

    void ins_calculate(double sourcedata[]);

    const Eigen::VectorXd& GetNavigationInfo();
    const Eigen::MatrixXd& GetCbn();

    void SetTimeStep(double step);

    void Feedback(Eigen::VectorXd &Xk);
    void Feedback1(Eigen::VectorXd &Xk,ivlocmsg::ivsensorgps& GPSData);

    int i_InitialAlign;

private:

    double Vp[3],Pos[3],Eulera[3];    //  ins pos/velo/attitude

    double f_Fab[3];                  //a,w
    double f_Wibb[3];

    double f_Winn[3];
    double f_Winb_COM[3];
    double f_Wnbb_COM[3];

    double f_Vn_pole_COM[3];          //pole  compensate
    double f_Rn_pole_COM[3];

    double V;
    double fp[3];
    double Quater[4];
    double Quater_temp[4];
    double Cbn[3][3];

    double f_Fn_COM[3];

    double g;
    double Rn,Rm;

    double f_H;
    double t_step;

    int ins_calculate_counter;                //imu calculate counter

    void Initial_Cbn();

    Eigen::VectorXd SinsInfo;
    Eigen::MatrixXd strapdown;

    ofstream ins_nav_out;
};

#endif
