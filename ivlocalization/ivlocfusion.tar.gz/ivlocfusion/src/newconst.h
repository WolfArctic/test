/**************************************************************
Copyright (C) 2015-2020, idriverplus(Beijing ZhiXingZhe Inc.

NodeName: ivlocfushion_node
FileName: newconst.h

Description:
1. define const value

History:
WangLeijie  17/09/13  1.0.0 built this module.
************************************************************/
#ifndef NEWCONST_H
#define NEWCONST_H

#define   GE          9.8                /*the gravity on the z coordinate on equator.*/
#define   W_IEE       7.292115E-5        /*the angular velocity of the earth.*/
#define   EPSILON    1.1920929E-07       /* SMALLEST X WHERE 1+X != 1         on equator.*/
#define   Wie       7.292115E-5          /*the angular velocity of the earth.*/
#define   Rf        0.00335281317790     /*1.0/298.257*/
#define   Ra        6378140.0            /*the long radium of the earth.*/
#define   Rb        6356755.3            /*the short radium of the earth.*/
#define   Re        6378137.0           /*the  radium of the earth.*/
#define   Re_       1.0/Re               /*the  rever radium of the earth.*/

#define SINSG0      9.80125
#define E           (1.0/298.257)

#define   Tg          3600
#define   Ta          3600

#define D2R         0.01745329251994       /*degree to radian*/
#define R2D         57.2957795131          /* Radians to degrees */
#define INV_TIME    2.77777778e-4          /*1/3600*/

#define GYRO_DRIFT_DEGREE  30.0
#define GYRO_WHITE_NOISE  ((GYRO_DRIFT_DEGREE*D2R*INV_TIME)*(GYRO_DRIFT_DEGREE*D2R*INV_TIME))
#define ACCE_DRIFT        0.001*9.8
#define GYRO_MARKVE       10.0
#define GYRO_MARKVE_NOISE ((GYRO_MARKVE*D2R*INV_TIME)*(GYRO_MARKVE*D2R*INV_TIME))

#define FALSE       0
#define TRUE        1

#define   NN        15
#define   MM        6
#define   NOISE     6
#define   ROW       3

//#define   M_PI      3.14159265

#define   gyro_const_drift_x  0       //gyro  const  drift
#define   gyro_const_drift_y  0
#define   gyro_const_drift_z  0

#define   Rx    0       //pole params
#define   Ry    0
#define   Rz    0

#define THROWING_TIME   0.05
#define ALIGNMENT_TIME  1

#define GPS_FIX_ERROR  0.013962634    //0.8 deg
#define GPS_IMU_FIX_ERROR  0.034906585    //2 deg

#endif