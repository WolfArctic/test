#include "psins.h"

CRAvar::CRAvar()
{
  maxCount = 2;
  nR0 = 6;

  memset(R0,0,sizeof(R0));
  memset(Rmax,0,sizeof(Rmax));
  memset(tau,0,sizeof(tau));

  memset(r0,0,sizeof(r0));
  memset(Rmaxflag,0,sizeof(Rmaxflag));
}

CRAvar::CRAvar(int nR0, int maxCount0)
{
  assert(nR0<RAMAX);
  this->nR0 = nR0;
  maxCount = maxCount0;
}

void CRAvar::set(double r0, double tau, double rmax, double rmin, int i)
{
  this->R0[i] = r0*r0;
  this->tau[i] = tau;
  this->r0[i] = 0.0;
  Rmaxflag[i] = maxCount;
  this->Rmax[i] = rmax==0.0 ? MAX_*this->R0[i] : rmax*rmax;
  this->Rmin[i] = rmin==0.0 ? MIN_*this->R0[i] : rmin*rmin;
}

void CRAvar::set(const Eigen::Vector3d &r0, const Eigen::Vector3d &tau, const Eigen::Vector3d &rmax, const Eigen::Vector3d &rmin)
{
  for(int i=0;i<3;i++)
  {
    set(r0(i), tau(i), rmax(i), rmin(i), i);
  }
}

void CRAvar::set(const Eigen::VectorXd &r0, const Eigen::VectorXd &tau, const Eigen::VectorXd &rmax, const Eigen::VectorXd &rmin)
{
  int len = nR0;
  for(int i=0;i<len;i++)
  {
    set(r0(i), tau(i), rmax(i), rmin(i), i);
  }
}

void CRAvar::Update(double r, double ts, int i)
{
  double tstau = ts>tau[i] ? 1.0 : ts/tau[i];
  double dr2=r-r0[i];

  dr2=dr2*dr2;
  r0[i]=r;

  if(dr2>R0[i])
  {
    R0[i]=dr2;
  }
  else
  {
    R0[i]=(1.0-tstau)*R0[i]+tstau*dr2;
  }

  if(R0[i]<Rmin[i])
  {
    R0[i]=Rmin[i];
  }

  if(R0[i]-Rmax[i]> 0.0000001)
  {
    R0[i]=Rmax[i];
    Rmaxflag[i]=maxCount;
  }
  else
  {
    Rmaxflag[i]-=Rmaxflag[i]>0;
  }
}

void CRAvar::Update(const Eigen::Vector3d &r, double ts)
{
  for(int i=0; i<3; i++)
  {
    Update(r(i), ts, i);
  }
}

void CRAvar::Update(const Eigen::VectorXd &r, double ts)
{
  for(int i=0; i<nR0; i++)
  {
    Update(r(i), ts, i);
  }
}

/*
double CRAvar::operator()(int k)
{
  return Rmaxflag[k] ? INF : sqrt(R0[k]);
}
*/
void CRAvar::setsapmletime(double t)
{
  ts = t;                           //set sample time

  for (int i = 0; i < RAMAX; ++i)   //set tau
  {
    tau[i] = ts * 10;
  }
}
