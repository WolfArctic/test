/****************************************************************
* Copyright (C) 2015-2020, idriverplus(BeiJing ZhiXingZhe, Inc.)
*
* NodeName: ivlocfusion
* FileName: locfusion.h, locfusion.cpp
*
* Description:
* 1. Receiving data from GPS/IMU/ODOM
* 2. Calculating Extended Kalman Filter.
* 3. Publishing filtered data.
*
* History:
* Wang Leijie   17/09/03    1.0.0    build this module.
****************************************************************/

#include "locfusion.h"

locfusion::locfusion(ros::NodeHandle nh) :
    Zk(6),
    SinsInfo(17),
    Cbn(3,3),
    MC_Velo(3)
{
    loopFrep = 100;

    ins_step = 0.01;
    kf_step = 0.1;

    save_navdata = true;
    gps_is_Horizontal = false;

    ZUPT_init_flag = true;

    mode = 0;

    //set step
    nh.param("ins_step", ins_step, ins_step);
    nh.param("kf_step", kf_step, kf_step);
    nh.param("IF_SAVE_NAVDATA", save_navdata, save_navdata);
    nh.param("GPS_IS_HORIZONTAL", gps_is_Horizontal, gps_is_Horizontal);

    //initial flags
    stage = 0;
    GPSData_OK = 0;
    Initial_KFPara_flag = 0;
    i_aligment_flag = 0;

    InitAlignMode = 'Z';

    ImuDataReady = 0;

    GPSDataReady = 0;

    ZUPT_flag = false;
    MC_flag = false;

    initial_flag = false;

    gps_counter = 0;
    imu_counter = 0;
    ins_counter = 0;
    kf_counter = 0;

    pitch_out = 0.0;
    roll_out = 0.0;
    heading_out = 0.0;

    locMsg.isvalid = 0;

    //memset(&previousGps,0,sizeof(previousGps));

    for (int i = 0; i < 3; i++)
    {
        Pos[i] = 0;
        Velo[i] = 0;
        Eulera[i] = 0;
        fn[i] = 0;
        f_vn_pole[i] = 0;
        f_rn_pole[i] = 0;
    }

    Zk.setZero();
    SinsInfo.setZero();
    Cbn.setZero();
    MC_Velo.setZero();
    MC_GPS_Velo.setZero();

    subGps = nh.subscribe(SUBTOPIC_GPS, SUBBUF_LEN, &locfusion::ChatterCallback_Gps, this);
    subImu = nh.subscribe(SUBTOPIC_IMU, SUBBUF_LEN, &locfusion::ChatterCallback_Imu,this);
 //   subImuRT = nh.subscribe(SUBTOPIC_IMURT, SUBBUF_LEN, &locfusion::ChatterCallback_ImuRT, this);

    //subOdom = nh.subscribe(SUBTOPIC_ODOM, SUBBUF_LEN, &locfusion::ChatterCallback_Odom, this);
    //subVisualOdom = nh.subscribe(SUBTOPIC_VISUALODOM, SUBBUF_LEN, &locfusion::ChatterCallback_VisualOdom, this);
    pubLoc = nh.advertise<ivlocmsg::ivmsglocpos>(PUBTOPIC, SUBBUF_LEN);
    pub_ros_nav = nh.advertise<sensor_msgs::Imu>(PUB_NAV_TOPIC, SUBBUF_LEN);
    //paramters
    std::cout << FRED("Copyright©2016-2020 idriverplus. All rights reserved ") << std::endl;
    std::cout << FYEL("*********ivlocfusion:parameters*************") << std::endl;

    std::cout << FGRN("ivlocloop frep: ") << loopFrep << std::endl;
    std::cout << FYEL("*********ivlocfusion:parameters end**********") << std::endl;

    if (save_navdata)
    {
      imu_out.open("../imudata.txt");   //for debug
      gps_out.open("../gpsdata.txt");
      nav_out.open("../nav_out.txt");

      fpnav = fopen("../NavGGA.txt","wt");
    }
}

//
locfusion::~locfusion()
{
  if(save_navdata)
  {
      imu_out.close();   //for debug
      gps_out.close();
      nav_out.close();

      fclose(fpnav);
  }
}

void locfusion::Run()
{
    ros::Rate rate(loopFrep);

    while(ros::ok())
    {
        ros::spinOnce();

        if(!initial_flag)
        {
            mysinscal.SetTimeStep(ins_step);   //set the step of ins calculate
            mykf.SetStep(kf_step);      //set the step of kf filter

            ravar.setsapmletime(ins_step);  //ZUPT

            initial_flag = true;

            std::cout<<"ins_step: "<<ins_step<<std::endl;
        }

        //aligment
        if (i_aligment_flag == 0)
        {
            if(ImuDataReady == 1)
            {
              ImuDataReady = 0;

              i_aligment_flag = mysinscal.InitialCaculate(currentGps,GPSDataReady,currentImu,InitAlignMode);
            }

            if (i_aligment_flag == 1)
            {
                std::cout << FYEL("/*********Aligment  Finish!*************/")<< std::endl;
            }
        }

        if (i_aligment_flag == 1)
        {
            FuseLoc();
           //---------------------------------------------------------
            //pub locpos
            locMsg.lat = Pos[0] * R2D;
            locMsg.lon = Pos[1] * R2D;;
            locMsg.heading = heading_out * R2D;
            locMsg.xg = Pos[2];
            locMsg.yg = currentGps.status;
            locMsg.angle = 0.0;
            locMsg.ug = 0.0;
            locMsg.vg = 0.0;
            locMsg.header.stamp = ros::Time::now();

            locMsg.velocity = sqrt(Velo[0]*Velo[0]+Velo[1]*Velo[1]);
            locMsg.isvalid = 1;

            pubLoc.publish(locMsg);
            //---------------------------------------------------------

            //pub sensor/Imu msg
            msg_nav.header.stamp = ros::Time::now();
            msg_nav.header.frame_id = "imu";

            msg_nav.linear_acceleration.x = currentImuRT.linear_acceleration.y;
            msg_nav.linear_acceleration.y = currentImuRT.linear_acceleration.x;
            msg_nav.linear_acceleration.z = -currentImuRT.linear_acceleration.z;

            msg_nav.angular_velocity.x = currentImuRT.angular_velocity.y;
            msg_nav.angular_velocity.y = currentImuRT.angular_velocity.x;
            msg_nav.angular_velocity.z = -currentImuRT.angular_velocity.z;

            tf2::Quaternion q;
            q.setRPY(roll_out, pitch_out, heading_out);
            msg_nav.orientation.x = q.x();
            msg_nav.orientation.y = q.y();
            msg_nav.orientation.z = q.z();
            msg_nav.orientation.w = q.w();

            pub_ros_nav.publish(msg_nav);

          //---------------------------------------------------------
            if(save_navdata)
            {
              gps_out<<setprecision(10)
                     << currentGps.lat*R2D <<"     "
                     << currentGps.lon*R2D <<"     "
                     << currentGps.height  <<"     "
                     << currentGps.ve <<"     "
                     << currentGps.vn <<"     "
                     << currentGps.vu <<"     "
                     << currentGps.heading*R2D <<"     "
                     << (int)currentGps.satenum <<"     "
                     << (int)currentGps.status <<"     "
                     << (int)currentGps.pos_status <<"     "
                     << (int)currentGps.att_status <<"     "
                     << gps_counter<<"     "
                     <<std::endl;

                nav_out << setprecision(10)<< Pos[0] * R2D << "        "
                        << Pos[1] * R2D<< "        "<< Pos[2]<<"      "
                        << Velo[0] <<"      "<< Velo[1]<<"      "
                        << Velo[2] <<"      "<< pitch_out*R2D <<"      "
                        << roll_out*R2D <<"       "
                        <<heading_out*R2D <<"     "
                        << ins_counter <<"     "<<kf_counter
                        << std::endl;

            /*
                $GPGGA,125632.20,4009.51055525,N,11614.02612764,E,4,20,0.7,45.3083,M,-9.4475,M,02,0001*49
                $GNRMC,125632.20,A,4009.51055525,N,11614.02612764,E,0.003,262.8,300817,6.7,W,D*34
           */

                double lat_out = Pos[0]*R2D;
                double lon_out = Pos[1]*R2D;

                char  data[100],tempLat,tempLon;
                short   Latdeg,Londeg;
                int   i,datalen;
                double  tempLoc,Latmin,Lonmin;
                tempLoc = fabs(lat_out);
                Latdeg = (int)tempLoc;
                Latmin = (tempLoc-Latdeg)*60;
                tempLat = (lat_out<0)?'S':'N';
                tempLoc = fabs(lon_out);
                Londeg = (int)tempLoc;
                Lonmin = (tempLoc-Londeg)*60;
                tempLon = (lon_out<0)?'W':'E';

                float alt_err = -9.4475;

/*
                sprintf(data,"$GNGGA,%.2d%.2d%6.3f,%.2d%7.4f,%c,%.3d%7.4f,%c,%d,%.2d,%f,%f,M,,M,,",
                  UTCTime->GNSS_UTC_Hour,UTCTime->GNSS_UTC_Minute,UTCTime->GNSS_UTC_Second,Latdeg,Latmin,tempLat,
                  Londeg,Lonmin,tempLon,LocPos->GNSS_PosFlg,LocPos->GNSS_PosSateNumAll,LocPos->GNSS_PDOP,LocPos->GNSS_Alt);
*/
                sprintf(data,"$GPGGA,%6.3f,%.2d%7.4f,%c,%.3d%7.4f,%c,%d,%.2d,%f,%f,M,%f,M,,,",
                  currentGps.utctime,Latdeg,Latmin,tempLat,
                  Londeg,Lonmin,tempLon,currentGps.status,currentGps.satenum,currentGps.hdop,currentGps.height,alt_err);

                int len = strlen(data);
                char temp_string[10];

                unsigned char checksum_value;
                int  index;

                checksum_value = 0;
                index = 1;
                while( index < len  && data[index] != '*')
                {
                  checksum_value ^= data[index];
                  index++;
                }

                sprintf(temp_string, "*%02X",(int)checksum_value);
                strcat(data,temp_string);

                fprintf(fpnav,"$GPGGA,%6.3f,%.2d%7.4f,%c,%.3d%7.4f,%c,%d,%.2d,%f,%f,M,%f,M,,,*%02X\n",
                      currentGps.utctime,Latdeg,Latmin,tempLat,Londeg,Lonmin,tempLon,currentGps.status,currentGps.satenum,currentGps.hdop,currentGps.height,alt_err,checksum_value);
            }
        }

        rate.sleep();
    }
}

void locfusion::FuseLoc()
{
    double imudata[6] = {0};

    if(ImuDataReady == 1)
    {
        ImuDataReady = 0;

        imudata[1] = currentImu.accelerationX;
        imudata[0] = currentImu.accelerationY;
        imudata[2] = -currentImu.accelerationZ;

        imudata[4] = currentImu.angularRateX;        //rad
        imudata[3] = currentImu.angularRateY;
        imudata[5] = -currentImu.angularRateZ;

        //------------------------------------------------
        Eigen::VectorXd  imu_in(6),tau_time(6),rmax(6),rmin(6);

        for (int i = 0; i < 6; ++i)
        {
          imu_in(i) = imudata[i];
          tau_time(i) = ins_step * 10;      //
        }

        rmax.setZero();
        rmin.setZero();

        if(ZUPT_init_flag == true)
        {
          ZUPT_init_flag = false;
          ravar.set(imu_in, tau_time, rmax, rmin);
        }

        if(ins_counter%10 == 0)
        {
          ravar.Update(imu_in,ins_step);
        }
/*
        std::cout<<"ravar.RO" <<"     "
                 <<ravar.R0[0]<<"     "
                 <<ravar.R0[1]<<"     "
                 <<ravar.R0[2]<<"     "
                 <<ravar.R0[3]<<"     "
                 <<ravar.R0[4]<<"     "
                 <<ravar.R0[5]<<"     "
                 <<std::endl;

        std::cout<<"ravar.Rmax" <<"     "
                 <<ravar.Rmax[0]<<"     "
                 <<ravar.Rmax[1]<<"     "
                 <<ravar.Rmax[2]<<"     "
                 <<ravar.Rmax[3]<<"     "
                 <<ravar.Rmax[4]<<"     "
                 <<ravar.Rmax[5]<<"     "
                 <<std::endl;

        std::cout<<"ravar.Rmaxflag" <<"     "
                 <<ravar.Rmaxflag[0]<<"     "
                 <<ravar.Rmaxflag[1]<<"     "
                 <<ravar.Rmaxflag[2]<<"     "
                 <<ravar.Rmaxflag[3]<<"     "
                 <<ravar.Rmaxflag[4]<<"     "
                 <<ravar.Rmaxflag[5]<<"     "
                 <<std::endl;
*/
        //------------------------------------------------

        mysinscal.ins_calculate(imudata);

        ins_counter++;

        SinsInfo = mysinscal.GetNavigationInfo();
        Cbn = mysinscal.GetCbn();

        pitch_out = atan(Cbn(2,1)/sqrt((Cbn(2,0)*Cbn(2,0)+Cbn(2,2)*Cbn(2,2))));
        roll_out = atan2(-Cbn(2,0),Cbn(2,2));
        heading_out = atan2(-Cbn(0,1),Cbn(1,1));

        //0-360
        if (heading_out>0)
        {
            heading_out = 2*M_PI -heading_out;
        }
        else
        {
          heading_out = -heading_out;
        }

        for (int i = 0; i < 3; i++)
        {
            Pos[i] = SinsInfo(i);
            Velo[i] = SinsInfo(i+3);
            fn[i] = SinsInfo(i+6);
            f_vn_pole[i] = SinsInfo(i+9);
            f_rn_pole[i] = SinsInfo(i+12);
        }

        rm = SinsInfo(15);
        rn = SinsInfo(16);

        if (GPSDataReady == 1)
        {
            GPSDataReady = 0;
            //
            if (currentGps.status == 4 && currentGps.satenum>=8)
            {
                stage = 1;
                mykf.Initial_KFPara(stage);
                GPSData_OK = 1;

                mode = 0;
                mykf.Set_HH_Mode(mode);
            }
            else  if(currentGps.status == 5 && currentGps.satenum>=8)
            {
                stage = 2;
                mykf.Initial_KFPara(stage);
                GPSData_OK = 1;

                mode = 0;
                mykf.Set_HH_Mode(mode);
            }
            else  if(currentGps.status == 2 && currentGps.satenum>=8)
            {
                stage = 3;
                mykf.Initial_KFPara(stage);
                GPSData_OK = 1;

                mode = 0;
                mykf.Set_HH_Mode(mode);
            }
            else if(currentGps.status == 1 && currentGps.satenum>=8)
            {
                stage = 4;
                mykf.Initial_KFPara(stage);
                GPSData_OK = 1;

                mode = 0;
                mykf.Set_HH_Mode(mode);
            }
            //30m
            if(fabs(currentGps.lat-previousGps.lat)>0.000005 || fabs(currentGps.lon-previousGps.lon)>0.000005 || fabs(currentGps.lat)>90*D2R || fabs(currentGps.lon)>180*D2R || fabs(currentGps.velocity)>50)
            {
                GPSData_OK = 0;
            }
            previousGps = currentGps;
            if(GPSData_OK == 0 && ravar.Rmaxflag[0] == 0 && ravar.Rmaxflag[1] == 0 && ravar.Rmaxflag[2]   == 0 && ravar.Rmaxflag[3] == 0 && ravar.Rmaxflag[4] == 0 && ravar.Rmaxflag[5] == 0 && Velo[0]<=ZUPT_Velocity && Velo[1]<=ZUPT_Velocity && Velo[2]<=ZUPT_Velocity)
            {
                ZUPT_flag = 1;    //Zero velocity update
                stage = 5;
                mykf.Initial_KFPara(stage);
                mode = 1;
                mykf.Set_HH_Mode(mode);
            }
            else if(GPSData_OK == 0 && 0)   //
            {
              MC_flag = 1;      //Moving Constraint
              stage = 6;
              mykf.Initial_KFPara(stage);

              MC_Velo.setZero();
              MC_GPS_Velo.setZero();

              MC_Velo(1) = sqrt(Velo[0]*Velo[0] + Velo[1]*Velo[1] + Velo[2]*Velo[2]);

              MC_GPS_Velo = Cbn*MC_Velo;

              mode = 2;
              mykf.Set_HH_Mode(mode);
            }
            std::cout << setprecision(10)
                      << "Ve_error:" << (Velo[0] - currentGps.ve)<<"     "
                      << "Vn_error: "<< (Velo[1] - currentGps.vn)<<"     "
                      << "Vu_error: "<< (Velo[2] - currentGps.vu)<<"     "
                      << "Lat_error: "<< (Pos[0] - currentGps.lat)*Re*cos(Pos[1])<<"     "
                      << "Lon_error: "<< (Pos[1] - currentGps.lon)*Re<<"     "
                      << "Alt_error: "<< (Pos[2] - currentGps.height)<<"     "
                      <<"heading_error:"<<(heading_out-currentGps.heading)*R2D<<"     "
                      <<"GPS_heading:"<<currentGps.heading*R2D<<"     "
                      <<"INS_heading:"<<heading_out*R2D
                      <<std::endl;

            std::cout<<endl;

        }

        if((GPSData_OK == 1 || ZUPT_flag == 1 || MC_flag == 1))
        {
            GPSData_OK = 0;
            ZUPT_flag = 0;
            MC_flag = 0;

            if (Initial_KFPara_flag == 0)
            {
                 Initial_KFPara_flag = 5;
                 mykf.Initial_KFPara(stage);
            }

            double ins2ecef_pos[3] = {0.0};
            double ECEF_gps_pos[3] = {0.0};

            double gps_ve=0.0,gps_vn=0.0,gps_vu=0.0;

            if(mode == 0)   //GPS_OK
            {
              gps_ve = currentGps.ve - f_vn_pole[0];
              gps_vn = currentGps.vn - f_vn_pole[1];
              gps_vu = currentGps.vu - f_vn_pole[2];

              currentGps.lon=(currentGps.lon-f_rn_pole[0]/((rn+Pos[2])*cos(currentGps.lat)));
              currentGps.lat=(currentGps.lat-f_rn_pole[1]/(rm+Pos[2]));
              currentGps.height=currentGps.height-f_rn_pole[2];
            }
            else if(mode == 1)  //ZUPT
            {
              gps_ve = 0;
              gps_vn = 0;
              gps_vu = 0;

            }
            else if(mode == 2)  //MC
            {
              gps_ve = MC_GPS_Velo(0);
              gps_vn = MC_GPS_Velo(1);
              gps_vu = MC_GPS_Velo(2);
            }

/*
            std::cout << "INS_ve:" << Velo[0]<<"     "
                      << "INS_vn:" << Velo[1]<<"     "
                      << "INS_vu:" << Velo[2]<<"     "
                      << "INS_Lat:"<< Pos[0]*R2D<< "     "
                      << "INS_lon:"<< Pos[1]*R2D<< "     "
                      << std::endl;

            std::cout << "GPS_ve: " << gps_ve<<"     "<<currentGps.ve<<"    "<< Velo[0]<<"     "
                      << "GPS_vn: " << gps_vn<<"     "<<currentGps.vn<<"    "<< Velo[1]<<"     "
                      << "GPS_vu: " << gps_vu<<"     "<<currentGps.vu<<"    "<< Velo[2]<<"     "
                      << "GPS_Lat:" <<currentGps.lat*R2D<<"     "
                      << "GPS_Lon:" <<currentGps.lon*R2D<<"     "
                      <<"satenum: "<<(int)currentGps.satenum<<"     "
                      <<"status: "<<(int)currentGps.status<<"     "
                      <<"Counter:"<<gps_counter<<"     "
                      <<"Mode:"<< mode
                      <<std::endl;
*/

            //observation value
            Zk(3) = Velo[0] - gps_ve;
            Zk(4) = Velo[1] - gps_vn;
            Zk(5) = Velo[2] - gps_vu;

            Zk(0) = (Pos[0]-currentGps.lat)*(rm+Pos[2]);
            Zk(1) = (Pos[1]-currentGps.lon)*(rn+Pos[2])*cos(Pos[0]);
            Zk(2) = (Pos[2]-(currentGps.height-f_rn_pole[2]));

/*
           std::cout << "Z(0): " << Zk(0)<<"     "
                     << "Z(1): " << Zk(1)<<"     "
                     << "Z(2): " << Zk(2)<<"     "
                     << "Z(3): " << Zk(3)<<"     "
                     << "Z(4): " << Zk(4)<<"     "
                     << "Z(5): " << Zk(5)<<"     "
                     <<"satenum: "<<(int)currentGps.satenum<<"     "
                     <<"status: "<<(int)currentGps.status<<"     "
                     <<"Counter:"<<gps_counter<<"     "
                     <<"mode:"<<mode
                     <<std::endl;
*/
            mykf.SetNowInsPara(SinsInfo,Cbn);

            mykf.Kalman(Zk);

            kf_counter++;

            Eigen::VectorXd Xk(15);
            Xk = mykf.GetXk();
/*
            std::cout << "X(0):" << Xk(0)<<"     "
                  << "X(1): " << Xk(1)<<"     "
                  << "X(2): " << Xk(2)<<"     "
                  << "X(3): " << Xk(3)<<"     "
                  << "X(4): " << Xk(4)<<"     "
                  << "X(5): " << Xk(5)<<"     "
                  << "X(6): " << Xk(6)<<"     "
                  << "X(7): " << Xk(7)<<"     "
                  << "X(8): " << Xk(8)<<"     "
                  <<std::endl;

            std::cout<< "ins_counter: "<< ins_counter <<"       "
                     << "kf_counter: "<< kf_counter <<"       "
                     << "imu_counter: "<<imu_counter<<"       "
                     << "gps_counter: "<< gps_counter<<"       "
                     << std::endl;
*/
            mysinscal.Feedback1(Xk,currentGps);
        }
    }

}

//
void locfusion::ChatterCallback_Gps(const ivlocmsg::ivsensorgps::ConstPtr& msg)
{
    currentGps = *msg;

    currentGps.lat = currentGps.lat * D2R;
    currentGps.lon = currentGps.lon * D2R;
    if(gps_is_Horizontal)
    {
      currentGps.heading = (currentGps.heading-90) * D2R;
    }
    else
    {
      currentGps.heading = (currentGps.heading) * D2R;
    }

    if (currentGps.heading<0)
    {
      currentGps.heading = currentGps.heading+2*M_PI;
    }

    currentGps.track_angle = currentGps.track_angle * D2R;

    gps_counter++;
/*
    std::cout << "gps_lat:" << currentGps.lat*R2D <<"     "
                  << "gps_lon: " << currentGps.lon*R2D <<"     "
                  << "gps_velocity: "<<currentGps.velocity<<"     "
                  << "gps_ve: " << currentGps.velocity * sin(currentGps.heading) <<"     "
                  << "gps_vn: " << currentGps.velocity * cos(currentGps.heading)<<"     "
                  << "gps_heading: "<<currentGps.heading*R2D<<"     "
                  <<"satenum: "<<(int)currentGps.satenum<<"     "
                  <<"status: "<<(int)currentGps.status<<"     "
                  <<"Counter:"<<gps_counter<<"     "
                  <<std::endl;
*/

    currentGps.isvalid = 1;
    if(0 == GPSDataReady)
      previousGps = currentGps;
    GPSDataReady = 1;
}

//
/*
void locfusion::ChatterCallback_Odom(const ivsensorodom::ivsensorodom::ConstPtr& msg)
{
    currentOdom = *msg;
  //  std::cout << "Odometer:"<< std::endl;
    //Odometer is always valid?
}*/

//
void locfusion::ChatterCallback_Imu(const ivlocmsg::ivsensorimu::ConstPtr& msg)
{
    currentImu = *msg;
  //  std::cout << "IMU:"<< currentImu.accelerationZ << std::endl;
    imu_counter++;

    if(save_navdata)
    {
        imu_out<<setprecision(10)
           << currentImu.accelerationX <<"     "
           << currentImu.accelerationY <<"     "
           << currentImu.accelerationZ <<"     "
           << currentImu.angularRateX <<"     "
           << currentImu.angularRateY <<"     "
           << currentImu.angularRateZ <<"     "
           << imu_counter
           <<std::endl;
    }

    ImuDataReady = 1;
}

//For RT
void locfusion::ChatterCallback_ImuRT(const sensor_msgs::Imu::ConstPtr& msg)
{
    currentImuRT = *msg;

    imu_counter++;

    imu_out<<setprecision(10)
           << currentImuRT.linear_acceleration.x <<"     "
           << currentImuRT.linear_acceleration.y <<"     "
           << currentImuRT.linear_acceleration.z <<"     "
           << currentImuRT.angular_velocity.x <<"     "
           << currentImuRT.angular_velocity.y <<"     "
           << currentImuRT.angular_velocity.z <<"     "
           << imu_counter
           <<std::endl;
/*
    std::cout << "ax:" << currentImuRT.linear_acceleration.x <<"     "
                  << "ay: " << currentImuRT.linear_acceleration.y <<"     "
                  << "az: "<< currentImuRT.linear_acceleration.z <<"     "
                  << "wx: " << currentImuRT.angular_velocity.x <<"     "
                  << "wy: " << currentImuRT.angular_velocity.y <<"     "
                  << "wz: "<< currentImuRT.angular_velocity.z <<"     "
                  <<std::endl;
*/
    ImuDataReady = 1;
}
